# prisma-guard

Prisma generator + runtime for input validation, query shape enforcement, and row-level tenant isolation helpers in RPC-style backends.

> **Scope isolation is best-effort at the Prisma extension level.** The scope extension injects tenant constraints into top-level operations only. It does not intercept nested writes and has known limitations around `findUnique`. Always combine the scope extension with query shapes for defense in depth.

## What it does

From your Prisma schema, `prisma-guard` helps you:

- Validate inputs (Zod schemas inferred from scalar types + optional `@zod` chains in schema docs)
- Enforce query shapes (allow only specific Prisma args/fields/ops per endpoint/caller)
- Inject row-level tenant constraints via a Prisma extension (top-level operations only)

Role-based access control (who is allowed to call which endpoints) is out of scope.

---

## Install
```bash
npm install prisma-guard zod @prisma/client
```

> `zod` (^4.0.0) and `@prisma/client` (^6.0.0 or ^7.0.0) are peer dependencies used at runtime.

---

## Setup (Prisma generator)

Add the generator to your Prisma schema:
```prisma
generator guard {
  provider                = "prisma-guard"
  output                  = "generated/guard"
  onInvalidZod            = "error"
  onAmbiguousScope        = "error"
  onMissingScopeContext   = "error"
  findUniqueMode          = "reject"
}
```

Generate:
```bash
npx prisma generate
```

The generator outputs a TypeScript file (`index.ts`) to the configured output directory. Your build toolchain must be configured to compile this file. If you use `ts-node`, `tsx`, `tsup`, or similar, this is handled automatically. If you use plain `tsc`, ensure the output directory is included in your `tsconfig.json` `include` paths.

---

## Mark tenant root models (`@scope-root`)

Add `/// @scope-root` to models that represent tenant roots:
```prisma
/// @scope-root
model Company {
  id String @id @default(uuid())
}

/// @scope-root
model User {
  id String @id @default(uuid())
}
```

`prisma-guard` will auto-scope models that have a **single unambiguous FK** to one of these root models.

If a model has **multiple FKs to the same scope root**, that model is excluded from the auto-scope map (configurable via `onAmbiguousScope`). You should handle those models explicitly with forced shape literals (see "Two-layer tenant isolation").

### Composite FK limitation

Models with composite foreign keys to a scope root (e.g. `@relation(fields: [tenantId, regionId], references: [tenantId, regionId])`) are treated as having multiple FKs to the same root and are excluded from auto-scoping. The `ScopeEntry` structure uses a single `fk` field and does not support composite keys. Handle these models via explicit query shapes with forced literals.

---

## Add field-level validation with `@zod`

Use `/// @zod ...` on a field to apply a Zod method chain to the inferred base type. **`@zod` chains apply to `guard.input()` schemas only.** Output schemas created by `guard.model()` use the base type without `@zod` chains, so they accept any value that matches the Prisma column type regardless of input constraints.
```prisma
model User {
  id    String  @id @default(uuid())
  email String  @unique /// @zod .email().max(255)
  name  String? /// @zod .min(1).max(100)
}
```

### `@zod` rules

* Exactly one `@zod` directive per field (multiple directives follow the `onInvalidZod` config).
* Directive must be a **method chain starting with `.`**, for example:

  * `/// @zod .min(1).max(100)`
* Allowed argument types:

  * string, number, boolean, null
  * arrays of those primitives
* Not allowed:

  * object literals, regex literals, template literals, identifiers, `Infinity`, `NaN`

Allowed methods:
`min`, `max`, `length`, `email`, `url`, `uuid`, `cuid`, `cuid2`, `ulid`, `trim`, `toLowerCase`, `toUpperCase`, `startsWith`, `endsWith`, `includes`, `datetime`, `ip`, `cidr`, `date`, `time`, `duration`, `base64`, `nanoid`, `emoji`, `int`, `positive`, `nonnegative`, `negative`, `nonpositive`, `finite`, `safe`, `multipleOf`, `step`, `gt`, `gte`, `lt`, `lte`, `nonempty`.

Not allowed (by design): `nullable`, `nullish`, `optional`, `default`. Use the builder options instead (`mode`, `allowNull`, `partial`).

### `refine` overrides `@zod` chains

When you use `refine` in `guard.input()`, the refine function receives a fresh base type **without** the `@zod` chain applied. This is intentional — `refine` is a full override. If a field has `/// @zod .email()` and you pass a `refine` for that field, the `.email()` validation will not be applied.
```ts
const schema = guard.input('User', {
  mode: 'create',
  pick: ['email'],
  refine: {
    email: (base) => base.min(5).max(255),
  },
})
```

---

## Usage

### Import generated config
```ts
import {
  SCOPE_MAP, TYPE_MAP, ENUM_MAP, ZOD_CHAINS, GUARD_CONFIG,
} from './generated/guard'
import type { ScopeRoot } from './generated/guard'
import { createGuard } from 'prisma-guard'
```

### Create the guard
```ts
const guard = createGuard<typeof TYPE_MAP, ScopeRoot>({
  scopeMap: SCOPE_MAP,
  typeMap: TYPE_MAP,
  enumMap: ENUM_MAP,
  zodChains: ZOD_CHAINS,
  guardConfig: GUARD_CONFIG,
})
```

### Custom logger

By default, the runtime uses `console.warn` for warning messages (e.g. when `onMissingScopeContext` is `"warn"`). You can provide a custom logger:
```ts
const guard = createGuard<typeof TYPE_MAP, ScopeRoot>({
  scopeMap: SCOPE_MAP,
  typeMap: TYPE_MAP,
  enumMap: ENUM_MAP,
  zodChains: ZOD_CHAINS,
  guardConfig: GUARD_CONFIG,
  logger: {
    warn: (msg) => myLogger.warn(msg),
  },
})
```

---

## Input validation

### Create vs update
```ts
const createUser = guard.input('User', {
  mode: 'create',
  pick: ['email', 'name'],
})

const updateUser = guard.input('User', {
  mode: 'update',
  pick: ['email', 'name'],
})
```

### Allowing nulls

By default, optional fields become optional, not nullable. If you want to accept `null`:
```ts
const updateUserNullable = guard.input('User', {
  mode: 'update',
  pick: ['name'],
  allowNull: true,
})
```

### Partial input schemas

If you want to accept partial objects:
```ts
const patchUser = guard.input('User', {
  mode: 'update',
  pick: ['email', 'name'],
  partial: true,
})
```

### Use in a route
```ts
app.post('/api/user', async (req, res) => {
  const data = createUser.parse(req.body)
  const user = await prisma.user.create({ data })
  res.json(user)
})
```

---

## Query shape enforcement

Shapes use Prisma-native syntax.

* `true` means: "client controls this value"
* literal values mean: "server forces this value"

### Static shapes (no context)
```ts
const findManySkills = guard.query('SkillsList', 'findMany', {
  where: {
    label: { contains: true },
  },
  orderBy: { label: true },
  take: { max: 100, default: 50 },
})

app.post('/api/skills/findMany', async (req, res) => {
  const args = findManySkills.parse(req.body)
  const results = await prisma.skillsList.findMany(args)
  res.json(results)
})
```

### Context-dependent shapes (single shape function)

> **Performance note:** Context-dependent shapes (shape functions) rebuild the Zod schema on every `.parse()` call because the shape depends on runtime context. Static shapes are built once and cached. For high-throughput endpoints, prefer static shapes with forced literals where possible.
```ts
type AppContext = { companyId: string }

const findManyAssignments = guard.query<AppContext>('JobAssignment', 'findMany', (ctx) => ({
  where: {
    clientCompanyId: { equals: ctx.companyId },
    startDate: { gte: true, lte: true },
  },
  include: {
    jobDescription: true,
    salesCompany: true,
  },
  take: { max: 50, default: 20 },
}))

app.post('/api/assignments/findMany', async (req, res) => {
  const args = findManyAssignments.parse(req.body, { ctx: req.ctx })
  const results = await prisma.jobAssignment.findMany(args)
  res.json(results)
})
```

### Caller-based shapes (multiple endpoints share one schema)

Provide a map of callers to shapes or shape functions. Client must send a `"caller"` string.
```ts
type AppContext = { companyId: string }

const findManyAssignments = guard.query<AppContext>('JobAssignment', 'findMany', {
  '/sales/assignments': (ctx) => ({
    where: {
      salesCompanyId: { equals: ctx.companyId },
      startDate: { gte: true, lte: true },
    },
    include: {
      jobDescription: true,
      talentProfile: true,
    },
    take: { max: 50, default: 20 },
  }),
  '/client/assignments': (ctx) => ({
    where: {
      clientCompanyId: { equals: ctx.companyId },
      startDate: { gte: true, lte: true },
    },
    include: {
      jobDescription: true,
      salesCompany: true,
    },
    take: { max: 50, default: 20 },
  }),
})

app.post('/api/assignments/findMany', async (req, res) => {
  const args = findManyAssignments.parse(req.body, { ctx: req.ctx })
  const results = await prisma.jobAssignment.findMany(args)
  res.json(results)
})
```

Client sends:
```json
{
  "caller": "/sales/assignments",
  "where": {
    "startDate": { "gte": "2025-01-01" }
  },
  "take": 20
}
```

### Caller patterns

You can use `:param` segments in caller keys to match variable paths:

* `"/org/:orgId/users"`
* `"/org/:orgId/users/:userId"`

A caller must match either:

* an exact key, or
* exactly one pattern key (otherwise it throws)

Caller matching is **case-sensitive**.

### Caller pattern details

`:param` segments in caller keys are **routing-only** — they match any value in that position but the matched values are not extracted or passed to the shape function. Use the context function (`ctx`) to pass runtime values into shapes.
```ts
const schema = guard.query<AppContext>('User', 'findMany', {
  '/org/:orgId/users': (ctx) => ({
    where: { orgId: { equals: ctx.orgId } },
  }),
})
```

### Caller troubleshooting

* If `"caller"` is missing: you'll get a shape error.
* If caller doesn't match any shape: you'll get an unknown-caller error.
* If caller matches multiple patterns: you'll get an ambiguity error listing the matches.

### Select support
```ts
const findManyUsers = guard.query('User', 'findMany', {
  '/admin/users': {
    where: {
      email: { contains: true },
    },
    select: {
      id: true,
      email: true,
      companies: {
        select: { companyId: true },
      },
    },
    take: { max: 100, default: 25 },
  },
})
```

Note: a shape cannot define both `select` and `include` at the same level (Prisma restriction).

### Distinct support

You can expose `distinct` for `findMany`, `findFirst`, and `findFirstOrThrow` by listing the allowed fields:
```ts
const findManyUsers = guard.query('User', 'findMany', {
  where: {
    email: { contains: true },
  },
  distinct: ['email', 'name'],
  take: { max: 100, default: 50 },
})
```

Client sends:
```json
{
  "where": { "email": { "contains": "test" } },
  "distinct": ["email"],
  "take": 20
}
```

The client can send a single field name or an array. Only the fields listed in the shape are allowed.

### Supported query methods

* `findMany`
* `findFirst`
* `findFirstOrThrow`
* `findUnique`
* `findUniqueOrThrow`
* `count`
* `aggregate`
* `groupBy`

### Known unsupported Prisma args

* `having` for `groupBy` — Prisma's `having` supports both scalar filters and aggregate filters (`_count`, `_avg`, etc.) with a complex type structure. Not yet implemented. Use application-level filtering after groupBy if needed.

---

## Error handling

`guard.input().parse()` and `guard.query().parse()` can throw the following error types:

* `ZodError` — input validation failed (from `zod`)
* `ShapeError` — structural issue with the request or shape configuration (status 400)
* `CallerError` — unknown or ambiguous caller key (status 400)
* `PolicyError` — access denied by scope or policy (status 403)

All prisma-guard errors have `status` and `code` properties for HTTP response mapping.

---

## Field type limitations

### Json fields

`Json` fields cannot be used in `where` or `orderBy` shape configs. Attempting to expose a Json field in either will throw a `ShapeError` at schema construction time. Json fields work normally in `guard.input()` (validated as `z.unknown()`) and `guard.model()` output schemas.

### Bytes fields

`Bytes` fields are validated as either a string or a `Uint8Array` instance. They cannot be used in `where` or `orderBy`.

---

## Row-level tenant isolation (Prisma extension)

> **Important:** The scope extension injects tenant constraints into **top-level Prisma operations only**. It does not intercept nested writes, has a best-effort `findUnique` verification path, and requires query shapes as a second layer to fully prevent unauthorized data access. See caveats below.
```ts
import { AsyncLocalStorage } from 'node:async_hooks'

const store = new AsyncLocalStorage<{ companyId: string; userId: string }>()

const prisma = new PrismaClient().$extends(
  guard.extension(() => {
    const ctx = store.getStore()
    return {
      Company: ctx?.companyId,
      User: ctx?.userId,
    }
  })
)

app.use((req, res, next) => {
  store.run(
    { companyId: req.auth.companyId, userId: req.auth.userId },
    next,
  )
})
```

### What the extension does

For scoped models:

* Reads:

  * Injects `AND` scope conditions into `where` for read operations (`findMany`, `findFirst`, `count`, etc.)
* Creates:

  * Overrides FK fields in `data` with the scope values from context
  * For `createMany` / `createManyAndReturn`, applies overrides to each element
  * Empty data arrays are rejected with a `ShapeError`
* Updates/deletes:

  * Injects scope into `where`
  * Strips FK fields from `data` for update operations (prevents changing tenant ownership)
* `findUnique` / `findUniqueOrThrow`:

  * Behavior controlled by `findUniqueMode` generator config (see below)
* Blocks `upsert` on scoped models — use `findFirst` + `create`/`update` with explicit scope conditions instead
* Rejects empty string scope values with a `PolicyError` (almost always a bug in the context function)

### `findUniqueMode`

Controls how the scope extension handles `findUnique` and `findUniqueOrThrow` on scoped models:

* `"reject"` **(recommended)**: Throws a `PolicyError` immediately. Forces you to use `findFirst` with explicit where conditions, which can be safely scoped via `AND` injection. This is the safest option.
* `"verify"` (default): Performs the query, then verifies the result's FK values match the scope context. Returns `null` (for `findUnique`) or throws `PolicyError` (for `findUniqueOrThrow`) if out of scope.

The `"verify"` mode has a known TOCTOU (time-of-check-to-time-of-use) race condition: between the query and scope check, a concurrent write could change the record's tenant FK. This window is extremely narrow in practice but exists. Use `"reject"` if this is unacceptable.
```prisma
generator guard {
  provider       = "prisma-guard"
  output         = "generated/guard"
  findUniqueMode = "reject"
}
```

### Scope applies to top-level operations only

The scope extension operates on the top-level Prisma operation via `$allOperations`. Nested writes (e.g. `create: { posts: { create: { ... } } }`) do not trigger `$allOperations` separately — this is standard Prisma extension behavior, not a prisma-guard limitation.

To prevent unauthorized nested writes, use `guard.query()` shapes to control which nested args are allowed. The two-layer approach (scope extension + query shapes) covers this: the extension handles top-level FK injection, and shapes prevent clients from including nested write paths you haven't explicitly exposed.

### `findUnique` known limitation: TOCTOU

The post-query scope check for `findUnique` / `findUniqueOrThrow` (when `findUniqueMode` is `"verify"`) has an inherent time-of-check-to-time-of-use (TOCTOU) race condition. Between the initial query and the scope verification query, a concurrent write could change the record's tenant FK. In practice this window is extremely narrow, but under high concurrency with frequent cross-tenant record transfers, a brief inconsistency is possible. If this is unacceptable for your use case, set `findUniqueMode` to `"reject"` and use `findFirst` with explicit where conditions instead.

### Important: missing scope context behavior

`onMissingScopeContext` controls what happens when the scope roots for a model are not present in the context function:

* `"error"`: throw on reads and mutations
* `"warn"`: warn on reads; **mutations still throw**
* `"ignore"`: ignore on reads; **mutations still throw**

#### Security warning (partial scoping)

If a model has multiple scope roots (example: both `Company` and `User`) and you set `onMissingScopeContext` to `"warn"` or `"ignore"`, reads may proceed with only the scope roots that are present.

That can leak data across tenants unless you guarantee your context function always provides all required roots for every request.

If you need strict enforcement, keep `onMissingScopeContext = "error"`.

---

## Output shaping (model schemas)

`guard.model()` produces Zod schemas for validating/shaping output data. **These schemas use base Prisma types without `@zod` chains**, so they accept any value that matches the column type. This is intentional — output schemas validate structure, not input constraints. Legacy data that doesn't pass `@zod` validation (e.g. an invalid email stored before validation was added) will still pass output validation.
```ts
const userOutput = guard.model('User', {
  pick: ['id', 'email', 'name'],
  include: {
    profile: { pick: ['bio', 'avatar'] },
  },
  strict: true,
})
```

* `pick` / `omit` apply to scalar fields.
* Relations must be included via `include: { rel: ... }`.
* Include depth is limited to 5 by default. Override with `maxDepth`:
```ts
const deepOutput = guard.model('User', {
  maxDepth: 8,
  include: {
    company: {
      include: {
        parent: {
          include: {
            region: {},
          },
        },
      },
    },
  },
})
```

---

## Two-layer tenant isolation

**Layer 1 — Scope extension (automatic, top-level only):**
Models with a single unambiguous FK to a `@scope-root` model are auto-scoped. The extension injects tenant constraints into top-level operations. It does not intercept nested writes.

**Layer 2 — Explicit forced shapes (manual):**
Models excluded from auto-scoping (for example, multiple FKs to the same root, or composite FKs) should be handled via `guard.query()` shapes where tenant constraints are literal values enforced by the server (usually via a shape function and context). This layer also prevents clients from accessing nested write paths you haven't explicitly exposed.

Both layers together provide defense in depth. Neither layer alone is sufficient for full tenant isolation.

---

## RBAC

Role-based access control is out of scope. Use a separate RBAC layer (middleware / route guards) to decide who can access which endpoints.

`prisma-guard` focuses on:

* what data is allowed in/out
* what query shape is allowed
* which tenant owns which rows (top-level operations)

---

## Generator options

| Option                  | Default    | Values                          | Description                                                                                          |
| ----------------------- | ---------- | ------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `onInvalidZod`          | `"error"`  | `"error"`, `"warn"`             | How to handle invalid `@zod` directives (including multiple directives per field)                     |
| `onAmbiguousScope`      | `"error"`  | `"error"`, `"warn"`, `"ignore"` | How to handle multi-FK to same root (excluded from scope map)                                        |
| `onMissingScopeContext` | `"error"`  | `"error"`, `"warn"`, `"ignore"` | What to do when scope context is missing. `warn`/`ignore` affect reads only; mutations always throw. |
| `findUniqueMode`        | `"verify"` | `"verify"`, `"reject"`          | How to handle `findUnique`/`findUniqueOrThrow` on scoped models. `"reject"` is recommended.          |

---

## License

MIT